import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';

import { Comment, User } from '../core';

@Component({
  selector: 'app-article-comment',
  templateUrl: './article-comment.component.html'
})
export class ArticleCommentComponent implements OnInit {
  constructor(
  ) {}

  @Input() comment: Comment;
  @Output() deleteComment = new EventEmitter<boolean>();

  canModify: boolean;

  ngOnInit() {
    // Load the current user's data
  }

  deleteClicked() {
    this.deleteComment.emit(true);
  }


}
