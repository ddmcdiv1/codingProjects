import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { User, Profile } from '../core';
import { concatMap ,  tap } from 'rxjs/operators';
import {DataService} from '../core/services/data.service';

@Component({
  selector: 'app-profile-page',
  templateUrl: './profile.component.html'
})
export class ProfileComponent implements OnInit {
  constructor(
    private dataService: DataService,
    private route: ActivatedRoute
  ) { }

  profile: Profile;
  currentUser: User;
  isUser: boolean;

  ngOnInit() {
    this.currentUser = this.dataService.getCurrentUser();
    this.profile = this.dataService.getProfile();
    this.isUser = true;
  }


}
