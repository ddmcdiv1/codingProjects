import { Component, OnInit } from '@angular/core';

import { User } from '../../core';
import {DataService} from '../../core/services/data.service';

@Component({
  selector: 'app-layout-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {
  constructor(private dataService: DataService
  ) {}

  currentUser: User;

  ngOnInit() {
    this.currentUser = {bio: 'test', email: 'test', image: 'https://images.halloweencostumes.com/products/10671/1-1/michael-myers-halloween-ii-mask-update.jpg', token: 'test', username: 'NewUser'};
    this.dataService.setCurrentUser(this.currentUser);
    this.dataService.setProfile({
      bio: this.currentUser.bio, following: false, image: this.currentUser.image, username: this.currentUser.username
    });

  }
}
