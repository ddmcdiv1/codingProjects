import {Injectable} from '@angular/core';
import {Profile, User} from '../index';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  myUser: User;
  myProfile: Profile;

  constructor() {
  }


  getCurrentUser(): User {
    return this.myUser;
  }

  setCurrentUser(newUser: User): void {
    this.myUser = newUser;
  }

  getProfile(): Profile {
    return this.myProfile;
  }

  setProfile(newProfile: Profile): void {
    this.myProfile = newProfile;
  }
}
