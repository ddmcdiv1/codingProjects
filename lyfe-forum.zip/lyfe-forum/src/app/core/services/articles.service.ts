import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ApiService } from './api.service';
import { Article, ArticleListConfig } from '../models';
import { map } from 'rxjs/operators';
import {marked} from 'marked';

@Injectable({providedIn: 'root'})
export class ArticlesService {
  constructor (
    private apiService: ApiService
  ) {}

  articles: Article[] = [];

  query(config: ArticleListConfig): {articles: Article[], articlesCount: number} {
    const params = {};

    Object.keys(config.filters)
    .forEach((key) => {
      params[key] = config.filters[key];
    });

    return {articles: this.articles, articlesCount: this.articles.length};
  }

  get(slug): Article[] {
    return this.articles.filter(a => a.slug.includes(slug));
  }

  getAll(): Article[] {
    return this.articles;
  }


  destroy(slug) {
    for (const article of this.articles) {
      if (article.slug === slug) {
        const index: number = this.articles.indexOf(article);
        if (index !== -1) {
          this.articles.splice(index, 1);
        }
      }
    }
  }

  save(article): Article[] {
    this.articles.push(article);
    return this.articles;
  }
}
