import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';

import {ApiService} from './api.service';
import {Comment} from '../models';
import {map} from 'rxjs/operators';
import {ArticlesService} from './articles.service';


@Injectable({providedIn: 'root'})
export class CommentsService {

  comments: Comment[] = [];

  constructor(
    private apiService: ApiService,
    private articleService: ArticlesService
  ) {
  }

/*  add(slug, payload): Comment[] {
    const article = this.articleService.get(slug)[0];
    article.comments.push(new Comment(payload));
    return article.comments;
  }

  getAll(slug): Observable<Comment[]> {
    return this.apiService.get(`/articles/${slug}/comments`)
      .pipe(map(data => data.comments));


  }

  destroy(commentId, articleSlug) {
    this.arti
  }*/

}
