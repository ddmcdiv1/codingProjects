import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import {ArticleListConfig, ArticlesService} from '../core';

@Component({
  selector: 'app-home-page',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  constructor(
    private router: Router,
    private articleService: ArticlesService
  ) {}

  isAuthenticated: boolean;
  listConfig: ArticleListConfig = {
    type: 'all',
    filters: {}
  };
  tags: Array<string> = ['this is a tag', 'test', 'test2', 'test3'];
  tagsLoaded = false;

  ngOnInit() {

  }

  setListTo(type: string = '', filters: Object = {}) {
    // If feed is requested but user is not authenticated, redirect to login

    // Otherwise, set the list object
    this.listConfig = {type: type, filters: filters};
    this.articleService.get(type);
  }
}
